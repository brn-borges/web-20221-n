export default function init(){
    return (
        <h1>Ola</h1>
    )
}