export default function init(){
    return <h1>Ola mundo!</h1>
}