import Calculadora from "../../components/Calculadora";

export default function init(){
    return (
        <Calculadora numero={10} />
    )
}