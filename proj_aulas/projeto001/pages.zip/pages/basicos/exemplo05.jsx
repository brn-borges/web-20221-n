import Titulo from "../../components/Titulo";

export default function init(){
    return(
        <>
            <Titulo></Titulo>
            <Titulo />
        </>
    )
}