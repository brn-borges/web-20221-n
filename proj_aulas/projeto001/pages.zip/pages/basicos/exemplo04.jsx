import React from "react"

export default function init(){
    return (
        <React.Fragment>
            <h1>Pagina de Cadastro</h1>
            <h2>SubPagina</h2>
        </React.Fragment>
    )
}

// export default function seg(){
//     return (
//         <div>
//             <h1>Pagina de Cadastro</h1>
//             <h2>SubPagina</h2>
//         </div>
//     )
// }