export default function init(){
    const conteudo = <div></div>
}