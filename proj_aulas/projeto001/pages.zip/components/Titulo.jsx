export default function Titulo(){
    return (
        <>
            <h1>Titulo</h1>
            <h2>SubTitulo</h2>
        </>
    )
}