export default function Calculadora(props){
    props.numero++
    return (
        <h1>{props.numero}</h1>
    )
}