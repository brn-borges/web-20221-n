import Linha from './Linha'

export default function init(){
    return(
        <div>
            <Linha></Linha>
            <Linha preta></Linha>
            <Linha></Linha>
            <Linha preta></Linha>
            <Linha></Linha>
            <Linha preta></Linha>
            <Linha></Linha>
            <Linha preta></Linha>
        </div>
    )    
}