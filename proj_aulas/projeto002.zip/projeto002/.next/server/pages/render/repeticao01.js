"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/render/repeticao01";
exports.ids = ["pages/render/repeticao01"];
exports.modules = {

/***/ "./pages/render/repeticao01.jsx":
/*!**************************************!*\
  !*** ./pages/render/repeticao01.jsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ init)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction init() {\n    const lista = [\n        'Cebolinha',\n        'Cascao',\n        'Monica',\n        \"Magali\"\n    ];\n    // //Forma 01\n    // function renderizarLista(){\n    //     const itens=[]\n    //     for(let i=0; i < lista.length; i++){\n    //         itens.push(<li key={i}>{lista[i]}</li>)\n    //     }\n    //     return itens\n    // }\n    // Forma 02\n    function renderizarLista() {\n        return lista.map((nome, i)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                children: nome\n            }, i, false, {\n                fileName: \"D:\\\\Bruno Borges Ferreira\\\\ADS - FATEC\\\\PROF ALYSSON\\\\proj_aulas\\\\projeto002\\\\pages\\\\render\\\\repeticao01.jsx\",\n                lineNumber: 21,\n                columnNumber: 39\n            }, this)\n        );\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"ul\", {\n            children: renderizarLista()\n        }, void 0, false, {\n            fileName: \"D:\\\\Bruno Borges Ferreira\\\\ADS - FATEC\\\\PROF ALYSSON\\\\proj_aulas\\\\projeto002\\\\pages\\\\render\\\\repeticao01.jsx\",\n            lineNumber: 25,\n            columnNumber: 13\n        }, this)\n    }, void 0, false);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9yZW5kZXIvcmVwZXRpY2FvMDEuanN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBZSxRQUFRLENBQUNBLElBQUksR0FBRSxDQUFDO0lBQzNCLEtBQUssQ0FBQ0MsS0FBSyxHQUFDLENBQUM7UUFDVCxDQUFXO1FBQ1gsQ0FBUTtRQUNSLENBQVE7UUFDUixDQUFRO0lBQ1osQ0FBQztJQUVELEVBQWE7SUFDYixFQUE4QjtJQUM5QixFQUFxQjtJQUNyQixFQUEyQztJQUMzQyxFQUFrRDtJQUNsRCxFQUFRO0lBQ1IsRUFBbUI7SUFDbkIsRUFBSTtJQUdKLEVBQVc7YUFDRkMsZUFBZSxHQUFFLENBQUM7UUFDdkIsTUFBTSxDQUFDRCxLQUFLLENBQUNFLEdBQUcsRUFBRUMsSUFBSSxFQUFFQyxDQUFDLCtFQUFNQyxDQUFFOzBCQUFVRixJQUFJO2VBQVJDLENBQUM7Ozs7OztJQUM1QyxDQUFDO0lBQ0QsTUFBTSw2RUFBQzs4RkFFRUUsQ0FBRTtzQkFDRUwsZUFBZTs7Ozs7OztBQUloQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcHJvamV0bzAwMi8uL3BhZ2VzL3JlbmRlci9yZXBldGljYW8wMS5qc3g/MTM2MiJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpbml0KCl7XHJcbiAgICBjb25zdCBsaXN0YT1bXHJcbiAgICAgICAgJ0NlYm9saW5oYScsXHJcbiAgICAgICAgJ0Nhc2NhbycsXHJcbiAgICAgICAgJ01vbmljYScsXHJcbiAgICAgICAgXCJNYWdhbGlcIlxyXG4gICAgXVxyXG5cclxuICAgIC8vIC8vRm9ybWEgMDFcclxuICAgIC8vIGZ1bmN0aW9uIHJlbmRlcml6YXJMaXN0YSgpe1xyXG4gICAgLy8gICAgIGNvbnN0IGl0ZW5zPVtdXHJcbiAgICAvLyAgICAgZm9yKGxldCBpPTA7IGkgPCBsaXN0YS5sZW5ndGg7IGkrKyl7XHJcbiAgICAvLyAgICAgICAgIGl0ZW5zLnB1c2goPGxpIGtleT17aX0+e2xpc3RhW2ldfTwvbGk+KVxyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgICByZXR1cm4gaXRlbnNcclxuICAgIC8vIH1cclxuXHJcblxyXG4gICAgLy8gRm9ybWEgMDJcclxuICAgIGZ1bmN0aW9uIHJlbmRlcml6YXJMaXN0YSgpe1xyXG4gICAgICAgIHJldHVybiBsaXN0YS5tYXAoKG5vbWUsIGkpID0+IDxsaSBrZXk9e2l9Pntub21lfTwvbGk+KVxyXG4gICAgfVxyXG4gICAgcmV0dXJuKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDx1bD5cclxuICAgICAgICAgICAgICAgIHtyZW5kZXJpemFyTGlzdGEoKX1cclxuICAgICAgICAgICAgPC91bD5cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufSJdLCJuYW1lcyI6WyJpbml0IiwibGlzdGEiLCJyZW5kZXJpemFyTGlzdGEiLCJtYXAiLCJub21lIiwiaSIsImxpIiwidWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/render/repeticao01.jsx\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/render/repeticao01.jsx"));
module.exports = __webpack_exports__;

})();