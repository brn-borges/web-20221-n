import Tabuleiro from '../components/Tabuleiro'


export default function init(){
    return (
        <div>
           <Tabuleiro> </Tabuleiro>
        </div>
  
    )
}