import Layout from "../components/Layout";

export default function Home() {
  return (
    <Layout  titulo="Pagina Inicial" subtitulo="Estamos construindo um tamplate admin">
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint amet sunt quasi a maiores exercitationem, eaque doloremque odio cupiditate, iste quidem. Nobis exercitationem officia veniam adipisci dolor iure rem natus? Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam quasi suscipit sequi minima autem minus veritatis mollitia officiis, non obcaecati tempore facilis maxime magni molestiae recusandae aperiam sint sit architecto.
      </p>
    </Layout>

  )
}
