export default function MenuLateral(){
    return (
        <aside>
            <h1>Menu</h1>
        </aside>
    )
}