import Linha from './Linha'

export default function tabuleiro(){
    return (
        <div>
            <Linha />
            <Linha preta/>
            <Linha />
            <Linha preta/>
            <Linha />
            <Linha preta/>
            <Linha />
            <Linha preta/>
        </div>
    )
}